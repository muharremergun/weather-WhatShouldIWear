//
//  WhatToWearViewModel.swift
//  brightsky
//
//  
//

import Foundation

struct WhatToWearViewModel{
    var weather = WeatherManager.shared.currentWeather
    
}
