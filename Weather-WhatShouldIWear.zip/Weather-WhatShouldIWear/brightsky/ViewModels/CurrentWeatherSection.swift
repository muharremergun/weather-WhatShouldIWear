//
//  CurrentWeatherSection.swift
//  brightsky
//
//
//

import Foundation

enum CurrentWeatherSection: CaseIterable {
    case current
    case hourly
    case daily
}
